import pygame, sys, random, math

def main(screen):
    WIDTH, HEIGHT = screen.get_size()
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 50)

    player = pygame.Rect(WIDTH//2, HEIGHT//2, 40, 40)
    bullets, enemies = [], []
    speed, shoot_delay, flash_timer, score = 6, 0, 0, 0
    running = True

    def spawn_enemy():
        side = random.choice(["top", "bottom", "left", "right"])
        if side == "top": pos = [random.randint(0, WIDTH), -20]
        elif side == "bottom": pos = [random.randint(0, WIDTH), HEIGHT+20]
        elif side == "left": pos = [-20, random.randint(0, HEIGHT)]
        else: pos = [WIDTH+20, random.randint(0, HEIGHT)]
        enemies.append(pygame.Rect(pos[0], pos[1], 35, 35))

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return  # go back to main menu

        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and player.top > 0: player.y -= speed
        if keys[pygame.K_s] and player.bottom < HEIGHT: player.y += speed
        if keys[pygame.K_a] and player.left > 0: player.x -= speed
        if keys[pygame.K_d] and player.right < WIDTH: player.x += speed

        if keys[pygame.K_SPACE] and shoot_delay <= 0:
            bullets.append(pygame.Rect(player.centerx - 4, player.top - 10, 8, 15))
            shoot_delay = 10
        shoot_delay -= 1

        for b in bullets[:]:
            b.y -= 10
            if b.bottom < 0: bullets.remove(b)

        if random.randint(0, 50) == 1: spawn_enemy()

        for e in enemies[:]:
            dx, dy = player.centerx - e.centerx, player.centery - e.centery
            dist = max(1, math.sqrt(dx**2 + dy**2))
            e.x += int(dx / dist * 2)
            e.y += int(dy / dist * 2)
            if e.colliderect(player):
                # Instead of recursion, just reset everything
                return main(screen)

        for b in bullets[:]:
            for e in enemies[:]:
                if b.colliderect(e):
                    bullets.remove(b)
                    enemies.remove(e)
                    score += 10
                    flash_timer = 3
                    break

        screen.fill((5, 5, 15))
        if flash_timer > 0:
            screen.fill((255, 255, 255))
            flash_timer -= 1

        pygame.draw.rect(screen, (0, 255, 255), player)
        for b in bullets: pygame.draw.rect(screen, (255, 60, 60), b)
        for e in enemies: pygame.draw.rect(screen, (255, 0, 255), e)

        score_text = font.render(f"Score: {score}", True, (0, 255, 100))
        screen.blit(score_text, (20, 20))

        pygame.display.flip()
        clock.tick(60)


# Standalone execution
if __name__ == "__main__":
    pygame.init()
    screen = pygame.display.set_mode((800, 600))
    pygame.display.set_caption("Coolio World")
    main(screen)
