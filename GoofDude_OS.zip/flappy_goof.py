import pygame, sys, random

pygame.init()

WIDTH, HEIGHT = 600, 800
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Flappy Goof")

clock = pygame.time.Clock()
font = pygame.font.Font(None, 60)

# --- Colors ---
BG = (5, 10, 30)
PIPE_COLOR = (0, 180, 255)
ORB_COLOR = (100, 200, 255)
TEXT_COLOR = (0, 255, 255)

# --- Player setup ---
orb = pygame.Rect(100, HEIGHT//2, 40, 40)
velocity = 0
gravity = 0.6
flap_strength = -10

# --- Pipe setup ---
pipes = []
pipe_gap = 200
pipe_width = 100
spawn_timer = 0
score = 0
game_over = False

def spawn_pipe():
    y = random.randint(150, HEIGHT - 250)
    pipes.append({"top": pygame.Rect(WIDTH, 0, pipe_width, y - pipe_gap//2),
                  "bottom": pygame.Rect(WIDTH, y + pipe_gap//2, pipe_width, HEIGHT)})

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                pygame.quit()
                sys.exit()
            if event.key == pygame.K_SPACE and not game_over:
                velocity = flap_strength
            elif event.key == pygame.K_SPACE and game_over:
                # restart
                orb.y = HEIGHT//2
                velocity = 0
                pipes.clear()
                score = 0
                game_over = False

    if not game_over:
        velocity += gravity
        orb.y += velocity

        spawn_timer += 1
        if spawn_timer > 100:
            spawn_pipe()
            spawn_timer = 0

        for pipe in pipes:
            pipe["top"].x -= 5
            pipe["bottom"].x -= 5
        pipes = [p for p in pipes if p["top"].x + pipe_width > 0]

        for pipe in pipes:
            if orb.colliderect(pipe["top"]) or orb.colliderect(pipe["bottom"]):
                game_over = True

        if orb.top <= 0 or orb.bottom >= HEIGHT:
            game_over = True

        for pipe in pipes:
            if pipe["top"].right == orb.left:
                score += 1

    # --- Draw ---
    screen.fill(BG)
    pygame.draw.ellipse(screen, ORB_COLOR, orb)

    for pipe in pipes:
        pygame.draw.rect(screen, PIPE_COLOR, pipe["top"])
        pygame.draw.rect(screen, PIPE_COLOR, pipe["bottom"])

    score_text = font.render(f"Score: {score}", True, TEXT_COLOR)
    screen.blit(score_text, (20, 20))

    if game_over:
        over_text = font.render("GAME OVER - Press SPACE", True, (255, 100, 100))
        screen.blit(over_text, (WIDTH//2 - over_text.get_width()//2, HEIGHT//2))

    pygame.display.flip()
    clock.tick(60)
